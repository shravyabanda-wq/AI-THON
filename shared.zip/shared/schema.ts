import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
});

export const moodEntries = pgTable("mood_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  date: timestamp("date").notNull().defaultNow(),
  moodScore: integer("mood_score").notNull(), // 1-5 scale
  moodEmoji: text("mood_emoji").notNull(),
  journalEntry: text("journal_entry"),
  sentimentScore: integer("sentiment_score"), // 1-5 from AI analysis
  sentimentConfidence: integer("sentiment_confidence"), // 0-100 percentage
  tags: text("tags").array().default(sql`'{}'::text[]`),
});

export const wellnessContent = pgTable("wellness_content", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  content: text("content").notNull(),
  category: text("category").notNull(), // breathing, exercise, journaling, meditation
  duration: integer("duration"), // in minutes
  imageUrl: text("image_url"),
  tags: text("tags").array().default(sql`'{}'::text[]`),
});

export const recommendations = pgTable("recommendations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  contentId: varchar("content_id").notNull().references(() => wellnessContent.id),
  reason: text("reason").notNull(),
  priority: integer("priority").notNull().default(1), // 1-5, higher is more important
  createdAt: timestamp("created_at").notNull().defaultNow(),
  isCompleted: boolean("is_completed").default(false),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertMoodEntrySchema = createInsertSchema(moodEntries).omit({ id: true, userId: true });
export const insertWellnessContentSchema = createInsertSchema(wellnessContent).omit({ id: true });
export const insertRecommendationSchema = createInsertSchema(recommendations).omit({ id: true });

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type MoodEntry = typeof moodEntries.$inferSelect;
export type InsertMoodEntry = z.infer<typeof insertMoodEntrySchema>;
export type WellnessContent = typeof wellnessContent.$inferSelect;
export type InsertWellnessContent = z.infer<typeof insertWellnessContentSchema>;
export type Recommendation = typeof recommendations.$inferSelect;
export type InsertRecommendation = z.infer<typeof insertRecommendationSchema>;
