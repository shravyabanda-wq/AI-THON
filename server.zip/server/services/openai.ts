import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_KEY || "your-api-key-here" 
});

export async function analyzeSentiment(text: string): Promise<{
  rating: number,
  confidence: number
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content:
            "You are a sentiment analysis expert specializing in mental health and emotional well-being. Analyze the sentiment of the text and provide a mood rating from 1 to 5 (1=very negative, 2=negative, 3=neutral, 4=positive, 5=very positive) and a confidence score between 0 and 1. Consider the emotional context and mental health implications. Respond with JSON in this format: { 'rating': number, 'confidence': number }",
        },
        {
          role: "user",
          content: text,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content);

    return {
      rating: Math.max(1, Math.min(5, Math.round(result.rating))),
      confidence: Math.max(0, Math.min(1, result.confidence)),
    };
  } catch (error) {
    console.error("Failed to analyze sentiment:", error);
    throw new Error("Failed to analyze sentiment: " + error.message);
  }
}

export async function generateWellnessRecommendations(
  moodHistory: { moodScore: number; sentimentScore?: number; tags: string[] }[],
  currentMood: number
): Promise<{ recommendations: string[]; insights: string }> {
  try {
    const moodData = moodHistory.map(entry => ({
      mood: entry.moodScore,
      sentiment: entry.sentimentScore || entry.moodScore,
      factors: entry.tags
    }));

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are a mental health and wellness expert. Based on mood patterns and current state, provide personalized wellness recommendations and insights. Focus on evidence-based practices like mindfulness, exercise, social connection, and stress management. Respond with JSON in this format: { 'recommendations': ['recommendation1', 'recommendation2', 'recommendation3'], 'insights': 'brief insight about patterns' }"
        },
        {
          role: "user",
          content: `Current mood: ${currentMood}/5. Recent mood history: ${JSON.stringify(moodData)}. Please provide 3 personalized wellness recommendations and a brief insight about mood patterns.`
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content);
    return {
      recommendations: result.recommendations || [],
      insights: result.insights || "Continue tracking your mood to identify patterns."
    };
  } catch (error) {
    console.error("Failed to generate recommendations:", error);
    return {
      recommendations: ["Take a 10-minute walk outside", "Practice deep breathing for 5 minutes", "Connect with a friend or family member"],
      insights: "Regular mood tracking helps identify patterns and improve well-being."
    };
  }
}
