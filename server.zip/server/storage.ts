import { type User, type InsertUser, type MoodEntry, type InsertMoodEntry, type WellnessContent, type Recommendation, type InsertRecommendation } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Mood entry methods
  getMoodEntries(userId: string, limit?: number): Promise<MoodEntry[]>;
  getMoodEntriesInDateRange(userId: string, startDate: Date, endDate: Date): Promise<MoodEntry[]>;
  createMoodEntry(entry: InsertMoodEntry & { userId: string }): Promise<MoodEntry>;
  getMoodEntryByDate(userId: string, date: Date): Promise<MoodEntry | undefined>;
  
  // Wellness content methods
  getAllWellnessContent(): Promise<WellnessContent[]>;
  getWellnessContentByCategory(category: string): Promise<WellnessContent[]>;
  
  // Recommendations methods
  getRecommendations(userId: string): Promise<Recommendation[]>;
  createRecommendation(recommendation: InsertRecommendation): Promise<Recommendation>;
  markRecommendationCompleted(id: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private moodEntries: Map<string, MoodEntry>;
  private wellnessContent: Map<string, WellnessContent>;
  private recommendations: Map<string, Recommendation>;

  constructor() {
    this.users = new Map();
    this.moodEntries = new Map();
    this.wellnessContent = new Map();
    this.recommendations = new Map();
    
    // Initialize with default user and wellness content
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Create default user
    const defaultUser: User = {
      id: "default-user",
      username: "sarah_m",
      firstName: "Sarah",
      lastName: "Mitchell"
    };
    this.users.set(defaultUser.id, defaultUser);

    // Initialize wellness content
    const wellnessItems: WellnessContent[] = [
      {
        id: "breathing-1",
        title: "5-Minute Breathing",
        description: "Quick stress relief technique",
        content: "Focus on deep, slow breathing. Inhale for 4 counts, hold for 4, exhale for 6.",
        category: "breathing",
        duration: 5,
        imageUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop",
        tags: ["stress", "anxiety", "quick"]
      },
      {
        id: "exercise-1", 
        title: "Morning Stretches",
        description: "Start your day with energy",
        content: "Gentle stretching routine to wake up your body and mind.",
        category: "exercise",
        duration: 10,
        imageUrl: "https://images.unsplash.com/photo-1593811167562-9cef47bfc4d7?w=400&h=300&fit=crop",
        tags: ["morning", "energy", "flexibility"]
      },
      {
        id: "journaling-1",
        title: "Gratitude Practice", 
        description: "Build positive thinking habits",
        content: "Write down three things you're grateful for each day.",
        category: "journaling",
        duration: 5,
        imageUrl: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=400&h=300&fit=crop",
        tags: ["gratitude", "positivity", "reflection"]
      }
    ];
    
    wellnessItems.forEach(item => this.wellnessContent.set(item.id, item));
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getMoodEntries(userId: string, limit?: number): Promise<MoodEntry[]> {
    const entries = Array.from(this.moodEntries.values())
      .filter(entry => entry.userId === userId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    return limit ? entries.slice(0, limit) : entries;
  }

  async getMoodEntriesInDateRange(userId: string, startDate: Date, endDate: Date): Promise<MoodEntry[]> {
    return Array.from(this.moodEntries.values())
      .filter(entry => 
        entry.userId === userId &&
        new Date(entry.date) >= startDate &&
        new Date(entry.date) <= endDate
      )
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }

  async createMoodEntry(entry: InsertMoodEntry & { userId: string }): Promise<MoodEntry> {
    const id = randomUUID();
    const moodEntry: MoodEntry = {
      ...entry,
      id,
      date: entry.date || new Date()
    };
    this.moodEntries.set(id, moodEntry);
    return moodEntry;
  }

  async getMoodEntryByDate(userId: string, date: Date): Promise<MoodEntry | undefined> {
    const dateStr = date.toISOString().split('T')[0];
    return Array.from(this.moodEntries.values())
      .find(entry => 
        entry.userId === userId && 
        entry.date.toISOString().split('T')[0] === dateStr
      );
  }

  async getAllWellnessContent(): Promise<WellnessContent[]> {
    return Array.from(this.wellnessContent.values());
  }

  async getWellnessContentByCategory(category: string): Promise<WellnessContent[]> {
    return Array.from(this.wellnessContent.values())
      .filter(content => content.category === category);
  }

  async getRecommendations(userId: string): Promise<Recommendation[]> {
    return Array.from(this.recommendations.values())
      .filter(rec => rec.userId === userId && !rec.isCompleted)
      .sort((a, b) => b.priority - a.priority);
  }

  async createRecommendation(recommendation: InsertRecommendation): Promise<Recommendation> {
    const id = randomUUID();
    const rec: Recommendation = {
      ...recommendation,
      id,
      createdAt: recommendation.createdAt || new Date(),
      isCompleted: false
    };
    this.recommendations.set(id, rec);
    return rec;
  }

  async markRecommendationCompleted(id: string): Promise<void> {
    const rec = this.recommendations.get(id);
    if (rec) {
      rec.isCompleted = true;
      this.recommendations.set(id, rec);
    }
  }
}

export const storage = new MemStorage();
