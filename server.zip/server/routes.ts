import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { analyzeSentiment, generateWellnessRecommendations } from "./services/openai";
import { insertMoodEntrySchema, insertRecommendationSchema } from "@shared/schema";
import { z } from "zod";

const DEFAULT_USER_ID = "default-user";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get current user
  app.get("/api/user", async (_req, res) => {
    try {
      const user = await storage.getUser(DEFAULT_USER_ID);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get mood entries
  app.get("/api/mood-entries", async (req, res) => {
    try {
      const { limit, startDate, endDate } = req.query;
      
      let entries;
      if (startDate && endDate) {
        entries = await storage.getMoodEntriesInDateRange(
          DEFAULT_USER_ID,
          new Date(startDate as string),
          new Date(endDate as string)
        );
      } else {
        entries = await storage.getMoodEntries(
          DEFAULT_USER_ID, 
          limit ? parseInt(limit as string) : undefined
        );
      }
      
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create mood entry with sentiment analysis
  app.post("/api/mood-entries", async (req, res) => {
    try {
      const validatedData = insertMoodEntrySchema.parse(req.body);
      
      // Analyze sentiment if journal entry is provided
      let sentimentScore = undefined;
      let sentimentConfidence = undefined;
      
      if (validatedData.journalEntry && validatedData.journalEntry.trim()) {
        try {
          const sentiment = await analyzeSentiment(validatedData.journalEntry);
          sentimentScore = sentiment.rating;
          sentimentConfidence = Math.round(sentiment.confidence * 100);
        } catch (error) {
          console.error("Sentiment analysis failed:", error);
          // Continue without sentiment analysis
        }
      }

      const moodEntry = await storage.createMoodEntry({
        ...validatedData,
        userId: DEFAULT_USER_ID,
        sentimentScore,
        sentimentConfidence,
        date: validatedData.date || new Date()
      });

      res.status(201).json(moodEntry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  // Get mood entry for today
  app.get("/api/mood-entries/today", async (_req, res) => {
    try {
      const today = new Date();
      const entry = await storage.getMoodEntryByDate(DEFAULT_USER_ID, today);
      res.json(entry);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get wellness content
  app.get("/api/wellness-content", async (req, res) => {
    try {
      const { category } = req.query;
      
      let content;
      if (category) {
        content = await storage.getWellnessContentByCategory(category as string);
      } else {
        content = await storage.getAllWellnessContent();
      }
      
      res.json(content);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get personalized recommendations
  app.get("/api/recommendations", async (_req, res) => {
    try {
      const recommendations = await storage.getRecommendations(DEFAULT_USER_ID);
      res.json(recommendations);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Generate new recommendations based on mood history
  app.post("/api/recommendations/generate", async (_req, res) => {
    try {
      const recentEntries = await storage.getMoodEntries(DEFAULT_USER_ID, 7);
      
      if (recentEntries.length === 0) {
        return res.json({ message: "No mood history available for recommendations" });
      }

      const currentMood = recentEntries[0]?.moodScore || 3;
      const aiRecommendations = await generateWellnessRecommendations(
        recentEntries.map(entry => ({
          moodScore: entry.moodScore,
          sentimentScore: entry.sentimentScore,
          tags: entry.tags || []
        })),
        currentMood
      );

      // Create recommendation records
      const wellnessContent = await storage.getAllWellnessContent();
      const createdRecommendations = [];

      for (const [index, recText] of aiRecommendations.recommendations.entries()) {
        // Match recommendation to wellness content
        const matchingContent = wellnessContent.find(content => 
          recText.toLowerCase().includes(content.category) ||
          content.title.toLowerCase().includes(recText.toLowerCase().split(' ')[0])
        ) || wellnessContent[index % wellnessContent.length];

        const recommendation = await storage.createRecommendation({
          userId: DEFAULT_USER_ID,
          contentId: matchingContent.id,
          reason: recText,
          priority: 5 - index, // Higher priority for earlier recommendations
          createdAt: new Date()
        });
        
        createdRecommendations.push(recommendation);
      }

      res.json({ 
        recommendations: createdRecommendations, 
        insights: aiRecommendations.insights 
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Mark recommendation as completed
  app.patch("/api/recommendations/:id/complete", async (req, res) => {
    try {
      await storage.markRecommendationCompleted(req.params.id);
      res.json({ message: "Recommendation marked as completed" });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get mood statistics
  app.get("/api/mood-stats", async (req, res) => {
    try {
      const { period = '7' } = req.query;
      const days = parseInt(period as string);
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);
      
      const entries = await storage.getMoodEntriesInDateRange(
        DEFAULT_USER_ID, 
        startDate, 
        new Date()
      );

      if (entries.length === 0) {
        return res.json({
          averageMood: 0,
          checkinsCompleted: 0,
          totalDays: days,
          moodImprovement: 0,
          streak: 0
        });
      }

      const averageMood = entries.reduce((sum, entry) => sum + entry.moodScore, 0) / entries.length;
      const checkinsCompleted = entries.length;
      
      // Calculate mood improvement (compare first half vs second half)
      const midpoint = Math.floor(entries.length / 2);
      const firstHalf = entries.slice(0, midpoint);
      const secondHalf = entries.slice(midpoint);
      
      const firstHalfAvg = firstHalf.length > 0 ? 
        firstHalf.reduce((sum, entry) => sum + entry.moodScore, 0) / firstHalf.length : 0;
      const secondHalfAvg = secondHalf.length > 0 ?
        secondHalf.reduce((sum, entry) => sum + entry.moodScore, 0) / secondHalf.length : 0;
      
      const moodImprovement = secondHalfAvg - firstHalfAvg;
      
      // Calculate current streak (consecutive days with entries)
      const allEntries = await storage.getMoodEntries(DEFAULT_USER_ID);
      let streak = 0;
      let currentDate = new Date();
      
      for (let i = 0; i < 30; i++) { // Check up to 30 days back
        const dateStr = currentDate.toISOString().split('T')[0];
        const hasEntry = allEntries.some(entry => 
          entry.date.toISOString().split('T')[0] === dateStr
        );
        
        if (hasEntry) {
          streak++;
        } else {
          break;
        }
        
        currentDate.setDate(currentDate.getDate() - 1);
      }

      res.json({
        averageMood: Number(averageMood.toFixed(1)),
        checkinsCompleted,
        totalDays: days,
        moodImprovement: Number(moodImprovement.toFixed(1)),
        streak
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
