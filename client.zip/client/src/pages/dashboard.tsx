import Navigation from "@/components/navigation";
import MoodCheckIn from "@/components/mood-check-in";
import MoodTrends from "@/components/mood-trends";
import MoodCalendar from "@/components/mood-calendar";
import WellnessRecommendations from "@/components/wellness-recommendations";
import WellnessLibrary from "@/components/wellness-library";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Plus, CheckCircle, Flame, TrendingUp } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { User } from "@shared/schema";

export default function Dashboard() {
  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  const { data: stats } = useQuery({
    queryKey: ["/api/mood-stats", { period: "7" }],
  });

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Welcome Section */}
        <section className="gradient-bg rounded-xl p-6 lg:p-8">
          <div className="flex flex-col lg:flex-row items-center justify-between">
            <div className="text-center lg:text-left">
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-2">
                Good morning, <span data-testid="text-user-first-name">{user?.firstName || "there"}</span>! 👋
              </h2>
              <p className="text-muted-foreground text-lg">How are you feeling today?</p>
            </div>
            <img 
              src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300" 
              alt="Peaceful sunrise over mountains" 
              className="w-48 h-36 object-cover rounded-lg mt-4 lg:mt-0"
            />
          </div>
        </section>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          {/* Left Column: Check-in & Trends */}
          <div className="xl:col-span-2 space-y-6">
            <MoodCheckIn />
            <MoodTrends />
            <MoodCalendar />
          </div>

          {/* Right Column: Recommendations & Wellness */}
          <div className="space-y-6">
            <WellnessRecommendations />
            
            {/* Quick Stats */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-foreground mb-4">This Week</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between" data-testid="stat-checkins-week">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-5 w-5 text-secondary" />
                      <span className="text-sm text-foreground">Check-ins completed</span>
                    </div>
                    <span className="font-semibold">
                      {stats ? `${stats.checkinsCompleted}/${stats.totalDays}` : "0/7"}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between" data-testid="stat-current-streak">
                    <div className="flex items-center space-x-2">
                      <Flame className="h-5 w-5 text-destructive" />
                      <span className="text-sm text-foreground">Current streak</span>
                    </div>
                    <span className="font-semibold">
                      {stats?.streak || 0} days
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between" data-testid="stat-mood-improvement">
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="h-5 w-5 text-secondary" />
                      <span className="text-sm text-foreground">Mood improvement</span>
                    </div>
                    <span className={`font-semibold ${
                      (stats?.moodImprovement || 0) >= 0 ? "text-secondary" : "text-destructive"
                    }`}>
                      {stats?.moodImprovement 
                        ? (stats.moodImprovement > 0 ? `+${stats.moodImprovement}` : stats.moodImprovement)
                        : "0"
                      }
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <WellnessLibrary />
          </div>
        </div>
      </main>

      {/* Floating Action Button */}
      <div className="fixed bottom-6 right-6">
        <Button
          size="icon"
          className="w-14 h-14 rounded-full shadow-lg hover:shadow-xl transition-all duration-200"
          data-testid="button-quick-checkin"
        >
          <Plus className="h-6 w-6" />
        </Button>
      </div>
    </div>
  );
}
