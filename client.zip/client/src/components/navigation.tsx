import { Heart, Menu, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import type { User as UserType } from "@shared/schema";

export default function Navigation() {
  const { data: user } = useQuery<UserType>({
    queryKey: ["/api/user"],
  });

  return (
    <header className="bg-card border-b border-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <Heart className="text-primary-foreground text-lg h-5 w-5" />
            </div>
            <h1 className="text-xl font-semibold text-foreground">MindWell</h1>
          </div>
          
          <nav className="hidden md:flex space-x-6">
            <a href="#dashboard" className="text-primary font-medium" data-testid="link-dashboard">Dashboard</a>
            <a href="#checkin" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-checkin">Check-in</a>
            <a href="#trends" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-trends">Trends</a>
            <a href="#wellness" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-wellness">Wellness</a>
          </nav>
          
          <div className="flex items-center space-x-3">
            <Button variant="ghost" size="icon" className="md:hidden" data-testid="button-menu">
              <Menu className="h-5 w-5" />
            </Button>
            <div className="hidden md:flex items-center space-x-2">
              <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                <User className="text-secondary-foreground text-sm h-4 w-4" />
              </div>
              <span className="text-sm text-muted-foreground" data-testid="text-username">
                {user ? `${user.firstName} ${user.lastName.charAt(0)}.` : "Loading..."}
              </span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
