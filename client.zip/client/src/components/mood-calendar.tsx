import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, eachDayOfInterval, isSameMonth, isSameDay } from "date-fns";
import type { MoodEntry } from "@shared/schema";

const MOOD_COLORS = {
  1: "bg-destructive/20 text-destructive-foreground",
  2: "bg-orange-100 text-orange-900",
  3: "bg-muted",
  4: "bg-secondary/20 text-secondary-foreground", 
  5: "bg-accent/20 text-accent-foreground"
};

const MOOD_EMOJIS = {
  1: "😢",
  2: "😔", 
  3: "😐",
  4: "😊",
  5: "😄"
};

export default function MoodCalendar() {
  const [currentDate, setCurrentDate] = useState(new Date());

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const calendarStart = startOfWeek(monthStart);
  const calendarEnd = endOfWeek(monthEnd);

  const { data: moodEntries = [] } = useQuery<MoodEntry[]>({
    queryKey: ["/api/mood-entries", { 
      startDate: calendarStart.toISOString(),
      endDate: calendarEnd.toISOString()
    }],
  });

  const calendarDays = eachDayOfInterval({
    start: calendarStart,
    end: calendarEnd
  });

  const getMoodForDate = (date: Date) => {
    return moodEntries.find(entry => 
      isSameDay(new Date(entry.date), date)
    );
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    if (direction === 'prev') {
      newDate.setMonth(newDate.getMonth() - 1);
    } else {
      newDate.setMonth(newDate.getMonth() + 1);
    }
    setCurrentDate(newDate);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Mood Calendar</CardTitle>
        </div>
        <div className="flex items-center justify-between">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => navigateMonth('prev')}
            data-testid="button-prev-month"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <h4 className="text-lg font-medium" data-testid="text-current-month">
            {format(currentDate, "MMMM yyyy")}
          </h4>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => navigateMonth('next')}
            data-testid="button-next-month"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {/* Day headers */}
        <div className="grid grid-cols-7 gap-1 text-center text-xs text-muted-foreground mb-2">
          <div className="p-2">Sun</div>
          <div className="p-2">Mon</div>
          <div className="p-2">Tue</div>
          <div className="p-2">Wed</div>
          <div className="p-2">Thu</div>
          <div className="p-2">Fri</div>
          <div className="p-2">Sat</div>
        </div>
        
        {/* Calendar grid */}
        <div className="grid grid-cols-7 gap-1" data-testid="calendar-grid">
          {calendarDays.map((day) => {
            const mood = getMoodForDate(day);
            const isCurrentMonth = isSameMonth(day, currentDate);
            const isToday = isSameDay(day, new Date());
            
            return (
              <div 
                key={day.toISOString()} 
                className="aspect-square p-1"
                data-testid={`calendar-day-${format(day, 'yyyy-MM-dd')}`}
              >
                <div className={`
                  w-full h-full rounded-lg flex flex-col items-center justify-center text-sm relative
                  ${mood ? MOOD_COLORS[mood.moodScore as keyof typeof MOOD_COLORS] : ''}
                  ${!isCurrentMonth ? 'text-muted-foreground/50' : ''}
                  ${isToday ? 'ring-2 ring-primary' : ''}
                  ${mood ? 'cursor-pointer hover:opacity-80' : ''}
                `}>
                  <span className={`${!isCurrentMonth ? 'text-muted-foreground' : 'text-foreground'}`}>
                    {format(day, 'd')}
                  </span>
                  {mood && (
                    <div className="absolute bottom-0.5 text-xs">
                      {MOOD_EMOJIS[mood.moodScore as keyof typeof MOOD_EMOJIS]}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Legend */}
        <div className="mt-4 pt-4 border-t border-border">
          <div className="text-xs text-muted-foreground mb-2">Legend:</div>
          <div className="flex flex-wrap gap-2 text-xs">
            {Object.entries(MOOD_EMOJIS).map(([score, emoji]) => (
              <div key={score} className="flex items-center gap-1">
                <div className={`w-4 h-4 rounded ${MOOD_COLORS[parseInt(score) as keyof typeof MOOD_COLORS]} flex items-center justify-center`}>
                  {emoji}
                </div>
                <span className="text-muted-foreground">
                  {score === "1" ? "Very Sad" : 
                   score === "2" ? "Sad" :
                   score === "3" ? "Neutral" :
                   score === "4" ? "Happy" : "Very Happy"}
                </span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
