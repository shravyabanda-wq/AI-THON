import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Activity, Brain, Phone, RefreshCw, Sparkles } from "lucide-react";
import type { Recommendation, WellnessContent } from "@shared/schema";

const CATEGORY_ICONS = {
  exercise: Activity,
  breathing: Brain,
  meditation: Brain,
  journaling: Sparkles,
  social: Phone,
};

export default function WellnessRecommendations() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: recommendations = [] } = useQuery<(Recommendation & { wellnessContent?: WellnessContent })[]>({
    queryKey: ["/api/recommendations"],
  });

  const { data: wellnessContent = [] } = useQuery<WellnessContent[]>({
    queryKey: ["/api/wellness-content"],
  });

  const generateRecommendationsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/recommendations/generate", {});
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "New recommendations generated!",
        description: "Fresh personalized recommendations based on your recent mood patterns.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/recommendations"] });
    },
    onError: (error) => {
      toast({
        title: "Error generating recommendations",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const completeRecommendationMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("PATCH", `/api/recommendations/${id}/complete`, {});
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Great job!",
        description: "Recommendation marked as completed.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/recommendations"] });
    },
    onError: (error) => {
      toast({
        title: "Error updating recommendation",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Enrich recommendations with wellness content
  const enrichedRecommendations = recommendations.map(rec => ({
    ...rec,
    wellnessContent: wellnessContent.find(content => content.id === rec.contentId)
  }));

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Today's Recommendations</CardTitle>
          <Button
            size="sm"
            variant="outline"
            onClick={() => generateRecommendationsMutation.mutate()}
            disabled={generateRecommendationsMutation.isPending}
            data-testid="button-generate-recommendations"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${generateRecommendationsMutation.isPending ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
        <p className="text-xs text-muted-foreground">
          Based on your recent mood patterns
        </p>
      </CardHeader>
      <CardContent>
        {enrichedRecommendations.length === 0 ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-3">
              <Sparkles className="text-primary text-xl h-8 w-8" />
            </div>
            <p className="text-muted-foreground text-sm mb-4">No recommendations available</p>
            <Button
              onClick={() => generateRecommendationsMutation.mutate()}
              disabled={generateRecommendationsMutation.isPending}
              data-testid="button-generate-first-recommendations"
            >
              {generateRecommendationsMutation.isPending ? "Generating..." : "Generate Recommendations"}
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {enrichedRecommendations.map((rec) => {
              const content = rec.wellnessContent;
              const IconComponent = content ? CATEGORY_ICONS[content.category as keyof typeof CATEGORY_ICONS] : Sparkles;
              const colorClass = rec.priority >= 4 ? "border-secondary" : rec.priority >= 3 ? "border-primary" : "border-accent";
              const bgClass = rec.priority >= 4 ? "bg-secondary/10" : rec.priority >= 3 ? "bg-primary/10" : "bg-accent/10";
              
              return (
                <div
                  key={rec.id}
                  className={`p-4 ${bgClass} rounded-lg border-l-4 ${colorClass}`}
                  data-testid={`recommendation-${rec.id}`}
                >
                  <div className="flex items-start space-x-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5 ${
                      rec.priority >= 4 ? "bg-secondary text-secondary-foreground" :
                      rec.priority >= 3 ? "bg-primary text-primary-foreground" : 
                      "bg-accent text-accent-foreground"
                    }`}>
                      <IconComponent className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-foreground">
                        {content?.title || "Wellness Activity"}
                      </h4>
                      <p className="text-sm text-muted-foreground mt-1">
                        {rec.reason}
                      </p>
                      {content?.description && (
                        <p className="text-sm text-muted-foreground mt-1">
                          {content.description}
                        </p>
                      )}
                      <div className="flex items-center gap-2 mt-2">
                        {content?.duration && (
                          <Badge variant="outline" className="text-xs">
                            {content.duration} min
                          </Badge>
                        )}
                        {content?.category && (
                          <Badge variant="secondary" className="text-xs">
                            {content.category}
                          </Badge>
                        )}
                      </div>
                      <Button
                        size="sm"
                        variant="link"
                        className="text-xs p-0 h-auto mt-2"
                        onClick={() => completeRecommendationMutation.mutate(rec.id)}
                        disabled={completeRecommendationMutation.isPending}
                        data-testid={`button-complete-${rec.id}`}
                      >
                        Mark as Complete
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
