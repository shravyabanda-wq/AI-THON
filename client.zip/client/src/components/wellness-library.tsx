import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Activity, Brain, Phone, Sparkles, ExternalLink } from "lucide-react";
import type { WellnessContent } from "@shared/schema";

const CATEGORY_ICONS = {
  exercise: Activity,
  breathing: Brain,
  meditation: Brain,
  journaling: Sparkles,
  social: Phone,
};

const CATEGORY_COLORS = {
  exercise: "bg-primary/20 text-primary",
  breathing: "bg-secondary/20 text-secondary", 
  meditation: "bg-secondary/20 text-secondary",
  journaling: "bg-accent/20 text-accent-foreground",
  social: "bg-destructive/20 text-destructive-foreground",
};

export default function WellnessLibrary() {
  const { data: wellnessContent = [], isLoading } = useQuery<WellnessContent[]>({
    queryKey: ["/api/wellness-content"],
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Wellness Library</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="flex items-start space-x-3">
                  <div className="w-12 h-12 bg-muted rounded-lg"></div>
                  <div className="flex-1">
                    <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-muted rounded w-1/2"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Wellness Library</CardTitle>
          <Button size="sm" variant="ghost" data-testid="button-view-all">
            View All
            <ExternalLink className="h-3 w-3 ml-1" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {wellnessContent.slice(0, 5).map((content) => {
            const IconComponent = CATEGORY_ICONS[content.category as keyof typeof CATEGORY_ICONS] || Sparkles;
            const colorClass = CATEGORY_COLORS[content.category as keyof typeof CATEGORY_COLORS] || "bg-muted";
            
            return (
              <div
                key={content.id}
                className="p-3 border border-border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer group"
                data-testid={`wellness-content-${content.id}`}
              >
                <div className="flex items-start space-x-3">
                  {content.imageUrl ? (
                    <img
                      src={content.imageUrl}
                      alt={content.title}
                      className="w-12 h-12 object-cover rounded-lg flex-shrink-0"
                    />
                  ) : (
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 ${colorClass}`}>
                      <IconComponent className="h-6 w-6" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-sm text-foreground group-hover:text-primary transition-colors">
                      {content.title}
                    </h4>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                      {content.description}
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge
                        variant="secondary"
                        className={`text-xs ${colorClass}`}
                      >
                        {content.category}
                      </Badge>
                      {content.duration && (
                        <Badge variant="outline" className="text-xs">
                          {content.duration} min
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        
        {wellnessContent.length === 0 && (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-3">
              <Sparkles className="text-primary h-8 w-8" />
            </div>
            <p className="text-muted-foreground text-sm">No wellness content available</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
