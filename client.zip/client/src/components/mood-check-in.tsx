import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { MoodEntry } from "@shared/schema";

const MOOD_OPTIONS = [
  { value: 1, emoji: "😢", label: "Very Sad" },
  { value: 2, emoji: "😔", label: "Sad" },
  { value: 3, emoji: "😐", label: "Neutral" },
  { value: 4, emoji: "😊", label: "Happy" },
  { value: 5, emoji: "😄", label: "Very Happy" }
];

const MOOD_TAGS = [
  "Work", "Sleep", "Exercise", "Family", "Social", "Weather", 
  "Health", "Money", "Relationships", "Stress", "Energy", "Focus"
];

export default function MoodCheckIn() {
  const [selectedMood, setSelectedMood] = useState<number>(3);
  const [journalEntry, setJournalEntry] = useState("");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Check if already checked in today
  const { data: todayEntry } = useQuery<MoodEntry>({
    queryKey: ["/api/mood-entries/today"],
  });

  const submitMoodMutation = useMutation({
    mutationFn: async (data: {
      moodScore: number;
      moodEmoji: string;
      journalEntry?: string;
      tags: string[];
    }) => {
      setIsAnalyzing(true);
      const response = await apiRequest("POST", "/api/mood-entries", data);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Mood check-in saved!",
        description: "Your mood has been recorded successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/mood-entries"] });
      queryClient.invalidateQueries({ queryKey: ["/api/mood-entries/today"] });
      queryClient.invalidateQueries({ queryKey: ["/api/mood-stats"] });
      
      // Reset form
      setJournalEntry("");
      setSelectedTags([]);
      setIsAnalyzing(false);
    },
    onError: (error) => {
      toast({
        title: "Error saving mood",
        description: error.message,
        variant: "destructive",
      });
      setIsAnalyzing(false);
    },
  });

  const handleSubmit = () => {
    const selectedMoodOption = MOOD_OPTIONS.find(m => m.value === selectedMood);
    if (!selectedMoodOption) return;

    submitMoodMutation.mutate({
      moodScore: selectedMood,
      moodEmoji: selectedMoodOption.emoji,
      journalEntry: journalEntry.trim() || undefined,
      tags: selectedTags,
    });
  };

  const toggleTag = (tag: string) => {
    setSelectedTags(prev => 
      prev.includes(tag) 
        ? prev.filter(t => t !== tag)
        : [...prev, tag]
    );
  };

  if (todayEntry) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            Today's Check-in Complete {todayEntry.moodEmoji}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground mb-4">
            You've already completed your mood check-in for today. Come back tomorrow!
          </p>
          <div className="text-sm text-muted-foreground">
            <p><strong>Mood:</strong> {MOOD_OPTIONS.find(m => m.value === todayEntry.moodScore)?.label}</p>
            {todayEntry.journalEntry && (
              <p className="mt-2"><strong>Journal:</strong> {todayEntry.journalEntry}</p>
            )}
            {todayEntry.tags && todayEntry.tags.length > 0 && (
              <div className="mt-2">
                <strong>Tags:</strong>
                <div className="flex flex-wrap gap-1 mt-1">
                  {todayEntry.tags.map(tag => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            {todayEntry.sentimentScore && (
              <p className="mt-2">
                <strong>AI Analysis:</strong> Sentiment score {todayEntry.sentimentScore}/5 
                {todayEntry.sentimentConfidence && ` (${todayEntry.sentimentConfidence}% confidence)`}
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Daily Mood Check-in</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Mood Selection */}
        <div>
          <h4 className="text-sm font-medium text-muted-foreground mb-4">
            How are you feeling right now?
          </h4>
          <div className="flex justify-between max-w-md mx-auto">
            {MOOD_OPTIONS.map((mood) => (
              <button
                key={mood.value}
                className={`mood-emoji w-14 h-14 rounded-full flex items-center justify-center text-2xl cursor-pointer ${
                  selectedMood === mood.value ? 'selected' : ''
                }`}
                onClick={() => setSelectedMood(mood.value)}
                data-testid={`button-mood-${mood.value}`}
              >
                {mood.emoji}
              </button>
            ))}
          </div>
          <div className="flex justify-between text-xs text-muted-foreground mt-2 max-w-md mx-auto px-2">
            {MOOD_OPTIONS.map((mood) => (
              <span key={mood.value}>{mood.label}</span>
            ))}
          </div>
        </div>

        {/* Journal Entry */}
        <div>
          <label className="block text-sm font-medium text-muted-foreground mb-3">
            Tell us more about how you're feeling (optional)
          </label>
          <Textarea
            value={journalEntry}
            onChange={(e) => setJournalEntry(e.target.value)}
            placeholder="I'm feeling pretty good today because..."
            className="min-h-[120px] resize-none"
            maxLength={500}
            data-testid="textarea-journal"
          />
          <div className="flex items-center justify-between mt-2">
            {isAnalyzing && (
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-secondary rounded-full animate-pulse"></div>
                <span className="text-xs text-muted-foreground">Analyzing sentiment...</span>
              </div>
            )}
            <span className="text-xs text-muted-foreground ml-auto">
              {journalEntry.length}/500
            </span>
          </div>
        </div>

        {/* Quick Tags */}
        <div>
          <h4 className="text-sm font-medium text-muted-foreground mb-3">
            What influenced your mood today?
          </h4>
          <div className="flex flex-wrap gap-2">
            {MOOD_TAGS.map((tag) => (
              <Badge
                key={tag}
                variant={selectedTags.includes(tag) ? "default" : "secondary"}
                className="cursor-pointer hover:bg-accent hover:text-accent-foreground transition-colors"
                onClick={() => toggleTag(tag)}
                data-testid={`tag-${tag.toLowerCase()}`}
              >
                {tag}
              </Badge>
            ))}
          </div>
        </div>

        <Button
          onClick={handleSubmit}
          className="w-full"
          disabled={submitMoodMutation.isPending}
          data-testid="button-submit-checkin"
        >
          {submitMoodMutation.isPending ? "Saving..." : "Save Today's Check-in"}
        </Button>
      </CardContent>
    </Card>
  );
}
