import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";
import { format, subDays, parseISO } from "date-fns";
import type { MoodEntry } from "@shared/schema";
import { TrendingUp } from "lucide-react";

const PERIOD_OPTIONS = [
  { value: "7", label: "7 Days" },
  { value: "30", label: "30 Days" },
  { value: "90", label: "90 Days" }
];

export default function MoodTrends() {
  const [selectedPeriod, setSelectedPeriod] = useState("7");

  const { data: moodEntries = [], isLoading } = useQuery<MoodEntry[]>({
    queryKey: ["/api/mood-entries", { 
      startDate: subDays(new Date(), parseInt(selectedPeriod)).toISOString(),
      endDate: new Date().toISOString()
    }],
  });

  const { data: stats } = useQuery({
    queryKey: ["/api/mood-stats", { period: selectedPeriod }],
  });

  // Prepare chart data
  const chartData = moodEntries.map(entry => ({
    date: format(parseISO(entry.date.toString()), "MMM dd"),
    mood: entry.moodScore,
    sentiment: entry.sentimentScore || entry.moodScore,
    fullDate: entry.date
  })).reverse(); // Reverse to show chronological order

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Your Mood Trends</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64 flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Your Mood Trends</CardTitle>
          <div className="flex space-x-2">
            {PERIOD_OPTIONS.map((period) => (
              <Button
                key={period.value}
                size="sm"
                variant={selectedPeriod === period.value ? "default" : "outline"}
                onClick={() => setSelectedPeriod(period.value)}
                data-testid={`button-period-${period.value}`}
              >
                {period.label}
              </Button>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {chartData.length === 0 ? (
          <div className="chart-container h-64 rounded-lg p-4 flex items-center justify-center">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <TrendingUp className="text-primary text-xl h-8 w-8" />
              </div>
              <p className="text-muted-foreground text-sm">No mood data available</p>
              <p className="text-muted-foreground text-xs mt-1">Start checking in daily to see trends</p>
            </div>
          </div>
        ) : (
          <>
            {/* Line Chart */}
            <div className="h-64 mb-6" data-testid="chart-mood-trends">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 12 }}
                    tickFormatter={(value) => value}
                  />
                  <YAxis 
                    domain={[1, 5]} 
                    tick={{ fontSize: 12 }}
                    tickFormatter={(value) => {
                      const labels = ["", "😢", "😔", "😐", "😊", "😄"];
                      return labels[value] || value;
                    }}
                  />
                  <Tooltip 
                    formatter={(value: number, name: string) => [
                      `${value}/5`,
                      name === "mood" ? "Self-reported Mood" : "AI Sentiment"
                    ]}
                    labelFormatter={(label) => `Date: ${label}`}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="mood" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2}
                    dot={{ fill: "hsl(var(--primary))" }}
                    name="mood"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="sentiment" 
                    stroke="hsl(var(--secondary))" 
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    dot={{ fill: "hsl(var(--secondary))" }}
                    name="sentiment"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Mood Insights */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-muted rounded-lg" data-testid="stat-average-mood">
                <div className="text-2xl font-bold text-primary">
                  {stats?.averageMood || "0"}
                </div>
                <div className="text-sm text-muted-foreground">Average Mood</div>
              </div>
              
              <div className="text-center p-4 bg-muted rounded-lg" data-testid="stat-checkins">
                <div className="text-2xl font-bold text-secondary">
                  {stats ? `${stats.checkinsCompleted}/${stats.totalDays}` : "0/0"}
                </div>
                <div className="text-sm text-muted-foreground">Check-ins</div>
              </div>
              
              <div className="text-center p-4 bg-muted rounded-lg" data-testid="stat-streak">
                <div className="text-2xl font-bold text-accent">
                  {stats?.streak || "0"}
                </div>
                <div className="text-sm text-muted-foreground">Day Streak</div>
              </div>
            </div>

            {stats && stats.moodImprovement !== 0 && (
              <div className="mt-4 p-3 bg-primary/10 rounded-lg border-l-4 border-primary">
                <p className="text-sm">
                  <strong>Mood Insight:</strong> Your mood has{" "}
                  <span className={stats.moodImprovement > 0 ? "text-secondary" : "text-destructive"}>
                    {stats.moodImprovement > 0 ? "improved" : "decreased"} by{" "}
                    {Math.abs(stats.moodImprovement).toFixed(1)} points
                  </span>{" "}
                  over this period.
                </p>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
